package service;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.mock;
import model.PizzaOrder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.*;

public class OrderServiceTest {

    /**
     * Parasoft Jtest UTA: Test for calculateTotal(PizzaOrder)
     *
     * @author ASUS
     * @see service.OrderService#calculateTotal(PizzaOrder)
     */
    @Test(timeout = 5000)
    public void testCalculateTotal() throws Throwable {
        // Given
        OrderService underTest = new OrderService();

        // When
        PizzaOrder order = mock(PizzaOrder.class);
        int getQuantityResult = 0; // UTA: configured value
        when(order.getQuantity()).thenReturn(getQuantityResult);

        double getUnitPriceResult = 0; // UTA: configured value
        when(order.getUnitPrice()).thenReturn(getUnitPriceResult);
        double result = underTest.calculateTotal(order);

        // Then - assertions for result of method calculateTotal(PizzaOrder)
        assertEquals(0.0d, result, 0.0);

    }

    /**
     * Parasoft Jtest UTA: Test for calculateTotal(PizzaOrder)
     *
     * @author ASUS
     * @see service.OrderService#calculateTotal(PizzaOrder)
     */
    @Test(timeout = 5000, expected = IllegalArgumentException.class)
    public void testCalculateTotal2() throws Throwable {
        // Given
        OrderService underTest = new OrderService();

        // When
        PizzaOrder order = mock(PizzaOrder.class);
//        when(order.getQuantity()).thenReturn(1);  // ✅ giá trị hợp lệ
//        when(order.getUnitPrice()).thenReturn(100.0); // ✅ hợp lệ
        int getQuantityResult = -1; // UTA: configured value
        when(order.getQuantity()).thenReturn(getQuantityResult);
        double result = underTest.calculateTotal(order);

        // Then - assertions for result of method calculateTotal(PizzaOrder)
        assertEquals(100.0d, result, 0.0);

    }

    /**
     * Parasoft Jtest UTA: Test for isLargeOrder(PizzaOrder)
     *
     * @author ASUS
     * @see service.OrderService#isLargeOrder(PizzaOrder)
     */
    @Test(timeout = 5000)
    public void testIsLargeOrder() throws Throwable {
        // Given
        OrderService underTest = new OrderService();

        // When
        PizzaOrder order = mock(PizzaOrder.class);
        boolean result = underTest.isLargeOrder(order);

        // Then - assertions for result of method isLargeOrder(PizzaOrder)
        assertFalse(result);

    }

    /**
     * Parasoft Jtest UTA: Test for calculateDiscountedTotal(PizzaOrder, double)
     *
     * @author ASUS
     * @see service.OrderService#calculateDiscountedTotal(PizzaOrder, double)
     */
    @Test(timeout = 5000)
    public void testCalculateDiscountedTotal() throws Throwable {
        // Given
        OrderService underTest = new OrderService();

        // When
        PizzaOrder order = mock(PizzaOrder.class);
        int getQuantityResult = 0; // UTA: configured value
        when(order.getQuantity()).thenReturn(getQuantityResult);

        double getUnitPriceResult = 0; // UTA: configured value
        when(order.getUnitPrice()).thenReturn(getUnitPriceResult);
        double discountPercent = 0; // UTA: configured value
        double result = underTest.calculateDiscountedTotal(order, discountPercent);

        // Then - assertions for result of method calculateDiscountedTotal(PizzaOrder, double)
        assertEquals(0.0d, result, 0.0);

    }

    /**
     * Parasoft Jtest UTA: Test for calculateDiscountedTotal(PizzaOrder, double)
     *
     * @author ASUS
     * @see service.OrderService#calculateDiscountedTotal(PizzaOrder, double)
     */
    @Test(timeout = 5000, expected = IllegalArgumentException.class)
    public void testCalculateDiscountedTotal2() throws Throwable {
        // Given
        OrderService underTest = new OrderService();

        // When
        PizzaOrder order = mock(PizzaOrder.class);
        int getQuantityResult = 1; // UTA: configured value
        when(order.getQuantity()).thenReturn(getQuantityResult);

        double getUnitPriceResult = 1; // UTA: configured value
        when(order.getUnitPrice()).thenReturn(getUnitPriceResult);
        double discountPercent = -1; // UTA: configured value
        underTest.calculateDiscountedTotal(order, discountPercent);

    }

    // Parasoft Jtest UTA: Object under test
    @InjectMocks
    OrderService underTest;
    private AutoCloseable closeable;

    // Parasoft Jtest UTA: Initialize object under test with mocked dependencies
    @Before
    public void setupMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @After
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    /**
     * Parasoft Jtest UTA: Test for calculateFinalAmount(PizzaOrder, double, double)
     *
     * @author ASUS
     * @see service.OrderService#calculateFinalAmount(PizzaOrder, double, double)
     */
    @Test(timeout = 5000)
    public void testCalculateFinalAmount() throws Throwable {
        // When
        PizzaOrder order = mock(PizzaOrder.class);
        int getQuantityResult = 0; // UTA: configured value
        when(order.getQuantity()).thenReturn(getQuantityResult);

        double getUnitPriceResult = 0; // UTA: configured value
        when(order.getUnitPrice()).thenReturn(getUnitPriceResult);
        double discountPercent = 0; // UTA: configured value
        double taxRatePercent = 1.0d; // UTA: default value
        double result = underTest.calculateFinalAmount(order, discountPercent, taxRatePercent);

        // Then - assertions for result of method calculateFinalAmount(PizzaOrder, double, double)
        assertEquals(0.0d, result, 0.0);

    }

    /**
     * Parasoft Jtest UTA: Test for calculateFinalAmount(PizzaOrder, double, double)
     *
     * @author ASUS
     * @see service.OrderService#calculateFinalAmount(PizzaOrder, double, double)
     */
    @Test(timeout = 5000, expected = IllegalArgumentException.class)
    public void testCalculateFinalAmount2() throws Throwable {
        // When
        PizzaOrder order = mock(PizzaOrder.class);
        int getQuantityResult = -1; // UTA: configured value
        when(order.getQuantity()).thenReturn(getQuantityResult);
        double discountPercent = 1.0d; // UTA: default value
        double taxRatePercent = 1.0d; // UTA: default value
        underTest.calculateFinalAmount(order, discountPercent, taxRatePercent);

    }

    /**
     * Parasoft Jtest UTA: Test for calculateFinalAmount(PizzaOrder, double, double)
     *
     * @author ASUS
     * @see service.OrderService#calculateFinalAmount(PizzaOrder, double, double)
     */
    @Test(timeout = 5000, expected = IllegalArgumentException.class)
    public void testCalculateFinalAmount3() throws Throwable {
        // When
        PizzaOrder order = mock(PizzaOrder.class);
        int getQuantityResult = 1; // UTA: configured value
        when(order.getQuantity()).thenReturn(getQuantityResult);

        double getUnitPriceResult = -1; // UTA: configured value
        when(order.getUnitPrice()).thenReturn(getUnitPriceResult);
        double discountPercent = 1.0d; // UTA: default value
        double taxRatePercent = 1.0d; // UTA: default value
        underTest.calculateFinalAmount(order, discountPercent, taxRatePercent);

    }

    /**
     * Parasoft Jtest UTA: Test for calculateFinalAmount(PizzaOrder, double, double)
     *
     * @author ASUS
     * @see service.OrderService#calculateFinalAmount(PizzaOrder, double, double)
     */
    @Test(timeout = 5000, expected = IllegalArgumentException.class)
    public void testCalculateFinalAmount4() throws Throwable {
        // When
        PizzaOrder order = mock(PizzaOrder.class);
        int getQuantityResult = 1; // UTA: configured value
        when(order.getQuantity()).thenReturn(getQuantityResult);

        double getUnitPriceResult = 1; // UTA: configured value
        when(order.getUnitPrice()).thenReturn(getUnitPriceResult);
        double discountPercent = -1; // UTA: configured value
        double taxRatePercent = 1.0d; // UTA: default value
        underTest.calculateFinalAmount(order, discountPercent, taxRatePercent);

    }

    /**
     * Parasoft Jtest UTA: Test for calculateFinalAmount(PizzaOrder, double, double)
     *
     * @author ASUS
     * @see service.OrderService#calculateFinalAmount(PizzaOrder, double, double)
     */
    @Test(timeout = 5000, expected = IllegalArgumentException.class)
    public void testCalculateFinalAmount5() throws Throwable {
        // When
        PizzaOrder order = mock(PizzaOrder.class);
        int getQuantityResult = 101; // UTA: configured value
        when(order.getQuantity()).thenReturn(getQuantityResult);

        double getUnitPriceResult = 0; // UTA: configured value
        when(order.getUnitPrice()).thenReturn(getUnitPriceResult);
        double discountPercent = 101; // UTA: configured value
        double taxRatePercent = 1.0d; // UTA: default value
        underTest.calculateFinalAmount(order, discountPercent, taxRatePercent);

    }

}
