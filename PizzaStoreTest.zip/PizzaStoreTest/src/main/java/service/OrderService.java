package service;

import model.PizzaOrder;

public class OrderService {

    public double calculateTotal(PizzaOrder order) {
        if (order.getQuantity() < 0 || order.getUnitPrice() < 0) {
            throw new IllegalArgumentException("Giá trị không hợp lệ");
        }
        return order.getQuantity() * order.getUnitPrice();
    }

    public boolean isLargeOrder(PizzaOrder order) {
        return order.getQuantity() >= 10;
    }

    public double calculateDiscountedTotal(PizzaOrder order, double discountPercent) {
        double total = calculateTotal(order);
        if (discountPercent < 0 || discountPercent > 100) {
            throw new IllegalArgumentException("Phần trăm giảm giá không hợp lệ");
        }
        return total * (1 - discountPercent / 100);
    }

    public double calculateTax(PizzaOrder order, double taxRatePercent) {
        double total = calculateTotal(order);
        return total * (taxRatePercent / 100);
    }

    public double calculateFinalAmount(PizzaOrder order, double discountPercent, double taxRatePercent) {
        double discountedTotal = calculateDiscountedTotal(order, discountPercent);
        double tax = discountedTotal * (taxRatePercent / 100);
        return discountedTotal + tax;
    }

    public boolean isVipOrder(PizzaOrder order) {
        return calculateTotal(order) > 1_000_000;
    }


}
