import model.PizzaOrder;
import service.OrderService;

public class Main {
    public static void main(String[] args) {
        // Tạo đơn hàng
        PizzaOrder order = new PizzaOrder("Pepperoni", 5, 80_000);
        OrderService service = new OrderService();

        // Tính tổng tiền ban đầu
        double total = service.calculateTotal(order);
        System.out.println("Tổng tiền gốc: " + total + " VND");

        // Áp dụng giảm giá
        double discountPercent = 10.0; // 10%
        double discountedTotal = service.calculateDiscountedTotal(order, discountPercent);
        System.out.println("Tổng sau giảm giá " + discountPercent + "%: " + discountedTotal + " VND");

        // Tính thuế
        double taxRatePercent = 8.0; // 8%
        double tax = service.calculateTax(order, taxRatePercent);
        System.out.println("Thuế (" + taxRatePercent + "%): " + tax + " VND");

        // Tính số tiền cuối cùng
        double finalAmount = service.calculateFinalAmount(order, discountPercent, taxRatePercent);
        System.out.println("Tổng tiền phải thanh toán: " + finalAmount + " VND");

        // Kiểm tra các điều kiện bổ sung
        if (service.isLargeOrder(order)) {
            System.out.println(">> Đây là đơn hàng số lượng lớn!");
        }

        if (service.isVipOrder(order)) {
            System.out.println(">> Đây là đơn hàng VIP!");
        }


    }
}
