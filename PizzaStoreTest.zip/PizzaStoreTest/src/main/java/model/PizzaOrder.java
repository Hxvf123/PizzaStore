package model;

public class PizzaOrder {
    private String pizzaName;
    private int quantity;
    private double unitPrice;

    public PizzaOrder(String pizzaName, int quantity, double unitPrice) {
        this.pizzaName = pizzaName;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public String getPizzaName() {
        return pizzaName;
    }
}
